VoltWerk Universal Ad Player

This is open-source software developed by VoltWerk Software, a part of VoltWerk Electronics.

License: Not specified.

How to use

1. Keep the Ad Player executable and the `media` folder in the same directory.
2. Place your images in the `media` folder.
3. Start the Ad Player. The images will automatically appear in the slideshow.
